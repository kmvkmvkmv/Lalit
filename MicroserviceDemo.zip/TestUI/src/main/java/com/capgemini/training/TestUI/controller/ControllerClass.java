package com.capgemini.training.TestUI.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.capgemini.training.TestUI.model.Customer;

//@RestController
@Controller
public class ControllerClass {
	//RestTemplate rest = new RestTemplate();
	
	@Autowired
	RestTemplate rest;
	
	/*@GetMapping("/customers")
	public Customer[] dispCustomers() {
		return rest.getForObject("http://localhost:1234/customers", Customer[].class);
	}
	
	@GetMapping("/customers/{id}")
	public Customer dispCustomer(@PathVariable int id) {
		return rest.getForObject("http://localhost:1234/customers/"+id, Customer.class);
	}*/
	
	@GetMapping("/customers")
	public String dispCustomers(Model model) {
		Customer[] customers = rest.getForObject("http://customer-crud/customers", Customer[].class);
		model.addAttribute("custs", customers);
		return "customers";
		
	}
	
	@GetMapping("/customers/{id}")
	public Customer dispCustomer(@PathVariable int id) {
		return rest.getForObject("http://localhost:1234/customers/"+id, Customer.class);
	}
	
	
}
