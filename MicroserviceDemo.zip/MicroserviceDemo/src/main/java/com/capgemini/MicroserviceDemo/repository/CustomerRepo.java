package com.capgemini.MicroserviceDemo.repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.MicroserviceDemo.entity.Customer;

public interface CustomerRepo extends CrudRepository<Customer, Integer>{
	
}
