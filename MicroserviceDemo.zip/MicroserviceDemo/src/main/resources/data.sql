insert into customer values(1, 'abc@gmail.com', 'Krishna', '9971535286');
insert into customer values(2, 'abcd@gmail.com', 'lalit', '456456546');
insert into customer values(3, 'abce@gmail.com', 'vikhyat', '456456546');
insert into customer values(4, 'abcf@gmail.com', 'rishabh', '45456456');
insert into customer values(5, 'abcg@gmail.com', 'pathak', '5465464');